package v1

import (
	"NAMESPACE/global"
	"NAMESPACE/global/response"
	resp "NAMESPACE/model/response"

	"github.com/gin-gonic/gin"
	"github.com/mojocn/base64Captcha"
)

var store = base64Captcha.DefaultMemStore

/*
// @Tags base
// @Summary 生成验证码
// @Security ApiKeyAuth
// @accept application/json
// @Produce application/json
// @Success 200 {string} string "{"success":true,"data":{},"msg":"获取成功"}"
// @Router /api/v1/base/captcha [get]
*/
func Captcha(c *gin.Context) {
	//字符,公式,验证码配置
	// 生成默认数字的driver
	driver := base64Captcha.NewDriverDigit(global.SERVER_CONFIG.CaptchaConfig.ImgHeight, global.SERVER_CONFIG.CaptchaConfig.ImgWidth, global.SERVER_CONFIG.CaptchaConfig.KeyLong, 0.7, 36)
	cp := base64Captcha.NewCaptcha(driver, store)
	id, b64s, err := cp.Generate()
	if err != nil {
		response.InternalServerError(err, c)
	} else {
		response.OkDetailed(resp.CaptchaResponse{
			CaptchaId: id,
			PicPath:   b64s,
		}, "验证码获取成功", c)
	}

	/*
	   //验证：
	   if ! store.Verify("验证码id", "传过来的验证码字符串", true) {
	   		response.FailWithMessage("验证码错误", c)
	   	}
	*/

}
