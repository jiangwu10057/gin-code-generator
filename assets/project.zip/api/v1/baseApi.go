package v1

import (
	"NAMESPACE/service"
)

var OpsOperateLogService service.OpsOperateLogService
