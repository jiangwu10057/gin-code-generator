package config

type BlackChainConfig struct {
	Url    string `mapstructure:"url" json:"url" yaml:"url"`
	AppKey string `mapstructure:"app-key" json:"appKey" yaml:"app-key"`
}
