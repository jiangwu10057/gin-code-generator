/**
 * @Description 统一认证配置
 * @Author q.wu
 * @Date 2020.12.01
 **/
package config

type CentralizedAuthorizeConfig struct {
	RemoteUrl string `mapstructure:"remote-url" json:"remoteUrl" yaml:"remote-url"`
}
