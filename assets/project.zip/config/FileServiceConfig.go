/**
 * @Description 文件服务minio映射
 * @Author chenwu
 * @Date 2022:04:08 11:10
 **/
package config

type FileServiceConfig struct {
	Domain string `mapstructure:"domain" json:"domain" yaml:"domain"`
	IP     string `mapstructure:"ip" json:"ip" yaml:"ip"`
}
