package config

type JwtConfig struct {
	SigningKey          string `mapstructure:"signing-key" json:"signingKey" yaml:"signing-key"`
	TokenExpiresSeconds int64  `mapstructure:"token-expires-seconds" json:"tokenExpiresSeconds" yaml:"token-expires-seconds"`
}
