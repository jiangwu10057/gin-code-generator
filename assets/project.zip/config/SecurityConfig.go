package config

type SecurityConfig struct {
	PlatformSecret   string `mapstructure:"platform-secret" json:"platformSecret" yaml:"platform-secret" ` //平台内部通信密钥
}

