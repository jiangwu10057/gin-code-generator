package config

type ServerConfig struct {
	SystemConfig               SystemConfig               `mapstructure:"system" json:"system" yaml:"system"`
	MySqlConfig                MySqlConfig                `mapstructure:"mysql" json:"mysql" yaml:"mysql"`
	OracleConfig               OracleConfig               `mapstructure:"oracle" json:"oracle" yaml:"oracle"`
	RedisConfig                RedisConfig                `mapstructure:"redis" json:"redis" yaml:"redis"`
	ZapConfig                  ZapConfig                  `mapstructure:"zap" json:"zap" yaml:"zap"`
	JwtConfig                  JwtConfig                  `mapstructure:"jwt" json:"jwt" yaml:"jwt"`
	CentralizedAuthorizeConfig CentralizedAuthorizeConfig `mapstructure:"centralized-authorize" json:"centralizedAuthorize" yaml:"centralized-authorize"`
	SignCheckConfig            SignCheckConfig            `json:"signCheckConfig" mapstructure:"sign-check-url"  yaml:"sign-check-url"`
	// oss
	LocalConfig   LocalConfig   `mapstructure:"local" json:"local" yaml:"local"`
	OssConfig     OssConfig     `mapstructure:"qiniu" json:"qiniu" yaml:"qiniu"`
	CaptchaConfig CaptchaConfig `mapstructure:"captcha" json:"captcha" yaml:"captcha"`
	DamengConfig  DMConfig      `mapstructure:"dameng" json:"dameng" yaml:"dameng"`
}
