/**
* @Description 闽政通确认网址
* @Author zhengjili
* @Date  2021/6/10  10:27
**/

package config

type SignCheckConfig struct {
	Url  string `mapstructure:"url"  json:"url" yaml:"url"`
	Name string `mapstructure:"name" json:"name" yaml:"name"` //签署app名称
}
