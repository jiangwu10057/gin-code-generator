package core

import (
	"GlobalAdmin/global"
	"GlobalAdmin/initialize"
	"fmt"
	"time"

	"go.uber.org/zap"
)

type server interface {
	ListenAndServe() error
}

func RunWindowsServer() {
	if global.SERVER_CONFIG.SystemConfig.UseMultipoint {
		global.LOGGER.Info("初始化redis服务")
		initialize.RedisInitialize()
	}

	Router := initialize.RoutersInitialize()

	address := fmt.Sprintf(":%d", global.SERVER_CONFIG.SystemConfig.Addr)

	s := initServer(address, Router)
	// 保证文本顺序输出
	// In order to ensure that the text order output can be deleted
	time.Sleep(10 * time.Microsecond)
	global.LOGGER.Info("server run success on ", zap.String("address", address))

	fmt.Printf(`
	欢迎使用 GlobalAdmin
	当前版本:V0.1
	默认自动化文档地址:http://127.0.0.1%s/swagger/index.html
`, address)
	global.LOGGER.Error(s.ListenAndServe().Error())
}
