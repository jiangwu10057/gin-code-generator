package global

import (
	"NAMESPACE/config"
	"NAMESPACE/model/request"

	"github.com/gin-gonic/gin"
	"github.com/go-redis/redis"
	"github.com/minio/minio-go/v7"
	"github.com/spf13/viper"
	"go.uber.org/zap"
	"gorm.io/gorm"
)

var (
	SERVER_CONFIG config.ServerConfig
	GORM_DB       *gorm.DB
	LOGGER        *zap.Logger
	REDIS         *redis.Client
	VIPER         *viper.Viper
	Oss           *minio.Client
)

//表前缀
const DB_PREFIX string = "DW."

const FORCE_EMPTY_STR string = "FORCE_EMPTY" //字段设置此值后，将会被更新为空""
const FORCE_ZERO_INT int = 42309874328493208
const FORCE_ZERO_INT64 int64 = 42309874328493208 //字段设置此值后，将会被更新为0
const FORCE_ZERO_UINT64 int64 = 42309874328493208
const FORCE_ZERO_FLOAT = 4.2309874328493208

//从JWT中解出的用户基本信息
const MEMBER_BASIC_DATA_KEY = "customClaimsModel"

//获取当前登录用户的基础信息
func GetMemberBasicData(c *gin.Context) *request.CustomClaimsModel {
	return c.MustGet(MEMBER_BASIC_DATA_KEY).(*request.CustomClaimsModel)
}

//secret 密钥判断（不为空时使用传入的，否则从url或者头部取）
func CheckSecret(secret string, c *gin.Context) (string, bool) {
	if secret == "" {
		secret = c.Query("secret")
		if secret == "" {
			secret = c.GetHeader("secret")
		}
		if secret == "" {
			secret = c.GetHeader("X-Secret")
		}
	}
	if secret == "" {
		return "密钥不能为空！", false
	}

	configSecret := SERVER_CONFIG.SecurityConfig.PlatformSecret
	if secret != configSecret {
		return "密钥不正确！", false
	}

	return "", true
}
