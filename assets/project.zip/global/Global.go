package global

import (
	"NAMESPACE/config"
	"NAMESPACE/model/request"

	"github.com/gin-gonic/gin"
	"github.com/go-redis/redis"
	"github.com/spf13/viper"
	"go.uber.org/zap"
	"gorm.io/gorm"
)

var (
	SERVER_CONFIG config.ServerConfig
	GORM_DB       *gorm.DB
	LOGGER        *zap.Logger
	REDIS         *redis.Client
	VIPER         *viper.Viper
)

//表前缀
const DB_PREFIX string = "DW."

//从JWT中解出的用户基本信息
const MEMBER_BASIC_DATA_KEY = "customClaimsModel"

//获取当前登录用户的基础信息
func GetMemberBasicData(c *gin.Context) *request.CustomClaimsModel {
	return c.MustGet(MEMBER_BASIC_DATA_KEY).(*request.CustomClaimsModel)
}
