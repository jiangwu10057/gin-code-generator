package response

import (
	"NAMESPACE/global"
	"NAMESPACE/utils"
	"encoding/json"
	"fmt"
	"net/http"

	"github.com/gin-gonic/gin"
)

type Response struct {
	Code    string      `json:"code"`
	Data    interface{} `json:"data"`
	Message string      `json:"message"`
}

const (
	ERROR                 string = "-1"
	INTERNAL_SERVER_ERROR        = "500"
	SUCCESS               string = "0"
)

func Result(code string, data interface{}, msg string, c *gin.Context) {
	// 原始
	/*	c.JSON(http.StatusOK, Response{
		code,
		data,
		msg,
	})*/

	//首字转换为小驼峰
	obj := Response{
		code,
		data,
		msg,
	}
	res, _ := json.Marshal(utils.JsonCamelCase{Value: obj})
	c.Header("Content-Type", "application/json")
	c.String(200, fmt.Sprintf("%s", res))
}

func ResultOriginal(code string, data interface{}, msg string, c *gin.Context) {
	// 原始
	c.JSON(http.StatusOK, Response{
		code,
		data,
		msg,
	})
}

func Ok(c *gin.Context) {
	Result(SUCCESS, map[string]interface{}{}, "操作成功", c)
}

func OkWithMessage(message string, c *gin.Context) {
	Result(SUCCESS, map[string]interface{}{}, message, c)
}

func OkWithData(data interface{}, c *gin.Context) {
	Result(SUCCESS, data, "调用成功", c)
}

//原始输出、不改变json键首字母为小写
func OkWithDataOriginal(data interface{}, c *gin.Context) {
	ResultOriginal(SUCCESS, data, "调用成功", c)
}

func OkDetailed(data interface{}, message string, c *gin.Context) {
	Result(SUCCESS, data, message, c)
}

func Fail(c *gin.Context) {
	Result(ERROR, map[string]interface{}{}, "调用失败", c)
}

func FailWithMessage(message string, c *gin.Context) {
	Result(ERROR, map[string]interface{}{}, message, c)
}

func FailWithDetailed(code interface{}, data interface{}, message string, c *gin.Context) {
	Result(fmt.Sprintf("%v", code), data, message, c)
}

func FailWithCustomCode(code interface{}, message string, c *gin.Context) {
	Result(fmt.Sprintf("%v", code), map[string]interface{}{}, message, c)
}

func InternalServerError(message interface{}, c *gin.Context) {
	msg := fmt.Sprintf("%v", message)
	errMsg := fmt.Sprintf("%v %v；参数：%v \n 详细信息：%v", c.Request.Method, c.FullPath(), c.Params, message)
	global.LOGGER.Error(errMsg)
	Result(INTERNAL_SERVER_ERROR, map[string]interface{}{}, msg, c)
}
