/**
 * @Description 平台产品编码
 * @Author q.wu
 * @Date 2021.1.7
 **/
package sysproductconst

//平台产品编码 sys_product.PRODUCT_ID
const (
	DATA_SET              = "da"        //数据资产管理2.0
	SM_VMC                = "sm-vmc"    //安全监控管理平台 - 可视化监控中心
	SV_SSAS               = "sm-ssas"   //安全监控管理平台 - 安全监管审核系统
	SM_LCQS               = "sm-lcqs"   //安全监控管理平台 - 日志归集查询系统
	DAVA                  = "dava"      //数据资产价值评估系统
	BEE_HUB               = "beehub"    //政务大数据蜂巢开发利用子平台
	BEE_HUB_DS            = "beehub-ds" //政务大数据蜂巢开发利用子平台(数据实时查询系统)
	DATA_SEARCH           = "ds"        //数据实时查询系统
	DATA_MING             = "dm"        //可视化数据挖掘系统
	BLOCK_AUTH            = "blockauth" //可信授权鉴证平台
	SECURITY_MONITOR      = "sm"        //安全监控管理子平台
	BACKGROUND_MANAGEMENT = "bm"        //后台管理系统
	OPERATION_MAINTENANCE = "bm-po"     //平台运维管理中心
	DATA_VALUE_OPERATION  = "bm-dvo"    //运营管理系统
	BM_WM                 = "bm-wm"     //平台网站内容管理中心
)

//访问权限
const (
	PM_NO_NEED_LOGIN   = iota //不需要登录就能调用
	PM_ONLY_NEED_LOGIN        //要登录才能调用
	PM_PRODUCT_LIMIT          //平台限制（指定平台能调用）
	PM_ONLY_BACKGROUND        //只有大后台用户有权限调用
)

//单位类型 MEMBER_INFO.ORG_TYPE
const (
	ORG_TYPE_DATA_PROVIDER        = iota + 1 //数据提供方	1
	ORG_TYPE_DATA_OPERATOR                   //数据运营方	2
	ORG_TYPE_DATA_USER                       //数据使用方	3
	ORG_TYPE_DATA_SUPERVISOR                 //数据监管方	4
	ORG_TYPE_SERVICE_PROVIDER                //服务商	  5
	ORG_TYPE_FIRST_LEVEL_DEV_TEAM            //一级开发团队 6
)

//工作台标识 product_workbench.WORKBENCH_ID
const (
	WORKBENCH_DEVELOPER            = "developer"            //开发者
	WORKBENCH_SOCIAL_DATA_PROVIDER = "social-data-provider" //社会数据提供方
	WORKBENCH_BACKGROUND_MGR       = "background-mgr"       //后台总管理员（系统管理）
	WORKBENCH_PRODUCT_OPT          = "product-opt"          //平台运维管理中心工作台
	WORKBENCH_WEBSITE_MGR          = "website-mgr"          //平台网站内容管理中心
	WORKBENCH_DATA_VALUE_OPT       = "data-value-opt"       //运营管理系统
	WORKBENCH_COMPANY_ACCOUNT      = "company-account"      //数据应用单位-单位管理账户（主账号）
	WORKBENCH_MEMBER_ACCOUNT       = "member-account"       //数据应用单位-成员账户（子账号）
	PROVINCE_DATA_OFFICE           = "province-data-office" //监管-省数办
	DATA_PRODUCT_COMPANY           = "data-product-company" //监管-数据生产单位
)

//系统角色 member_account.USER_TYPE;  子账号模型权限member_account.ROLE_IDS
const (
	ROLE_MEMBER                 = "1"               //1	         机构普通用户	    	机构普通用户
	ROLE_MEMBER_INFO_ADMIN      = "2"               //2	         管理员		   	 	机构管理用户(或主账号)
	ROLE_PLATFORM_ADMIN         = "3"               //3	         管理员		   	 	平台管理用户
	ROLE_ADMIN                  = "4"               //4	         平台角色配置用户		平台角色配置用户 (未使用)
	ROLE_CUSTOMER_SERVICE       = "5"               //5	         客服管理		    运营管理中心-客服管理
	ROLE_CUSTOMER_SERVICE_ADMIN = "6"               //6	         客服			    运营管理中心-客服
	ROLE_SCENE_MANAGE           = "7"               //7	         场景管理		    运营管理中心-场景管理
	ROLE_EXAMINER               = "8"               //8	         审批员		    	拥有查看权限及应用场景审批权限
	ROLE_EXPECT_LEADER          = "9"               //9	         数据开放开发专家	    作为专家组组长对应用场景进行评审的权限
	ROLE_SUPERVISOR             = "10"              //10	     监管员		    	仅拥有查看权限
	ROLE_DATA_PRODUCER          = "11"              //11	     数据生产单位	    	应用场景进行意见征求及查看数据输出备案的权限
	ROLE_SCENE_DEVELOP          = "101"             //101	     场景开发(原1)	    子账号模型权限
	ROLE_MODEL_MANAGE           = "102"             //102	     模型管理(原2)	    子账号模型权限
	ROLE_SCENE_VIEW             = "103"             //103	     场景查看(原3)	    子账号模型权限
	ROLE_CATEGORY_BUY           = "104"             //104	     目录购买(原4)	    子账号模型权限
	ROLE_ALGORITHM_EXPECT       = "16"              //16	     算法专家		    作为专家组成员对应用场景进行评审的权限
	ROLE_GROUP_LEADER           = "17"              //17	     组长		    	数据目录资源管理系统-组长
	ROLE_GROUP_MEMBER           = "18"              //18	     组员		    	数据目录资源管理系统-组员
	MAX_SYTEM_ROLE_ID           = "100"             //最大的系统角色编号
)

//AUTH_ROLE.ROLE_TYPE
const (
	ROLE_TYPE_SYSTEM = "系统策略"    //系统策略
	ROLE_TYPE_MEMBER = "会员自定义策略" //会员自定义策略(前台添加,如客服组)
	ROLE_TYPE_MODEL  = "模型策略"    //模型策略－子账号
	ROLE_TYPE_CUSTOM = "自定义策略" //自定义策略(运维后台自定义添加)
)

//注册方式
const (
	BM_DVO_REGISTER = iota + 1 //运营管理系统注册
	WEB_REGISTER               //网站注册
	BM_PO_REGISTER             //平台运维管理中心
	SM_REGISTER                //监管平台注册
)

const (
	BIG_DATA_OFFICE_MEMBER_ID = "9C10103EB57B48BC966B967718D324B7" //大数据管理局  memberId
	EXPECT_MEMBER_ID          = "9C10103EB57B48BC966B967718D324BD" //专家memberId
)
