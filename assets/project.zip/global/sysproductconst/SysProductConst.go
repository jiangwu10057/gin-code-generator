/**
 * @Description 平台产品编码
 * @Author q.wu
 * @Date 2021.1.7
 **/
package sysproductconst

const (
	DATA_SET              = "da"        //数据资产管理2.0
	SM_VMC                = "sm-vmc"    //安全监控管理平台 - 可视化监控中心
	SV_SSAS               = "sm-ssas"   //安全监控管理平台 - 安全监管审核系统
	SM_LCQS               = "sm-lcqs"   //安全监控管理平台 - 日志归集查询系统
	DAVA                  = "dava"      //数据资产价值评估系统
	BEE_HUB               = "beehub"    //政务大数据蜂巢开发利用子平台
	DATA_SEARCH           = "ds"        //数据实时查询系统
	DATA_MING             = "dm"        //可视化数据挖掘系统
	BLOCK_AUTH            = "blockauth" //可信授权鉴证平台
	SECURITY_MONITOR      = "sm"        //安全监控管理子平台
	BACKGROUND_MANAGEMENT = "bm"        //后台管理系统
	OPERATION_MAINTENANCE = "bm-po"     //平台运维管理中心
)

const (
	PM_NO_NEED_LOGIN   = iota //不需要登录就能调用
	PM_ONLY_NEED_LOGIN        //要登录才能调用
	PM_PRODUCT_LIMIT          //平台限制（指定平台能调用）
	PM_ONLY_BACKGROUND        //只有大后台用户有权限调用
)
