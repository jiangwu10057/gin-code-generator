package initialize

import (
	"NAMESPACE/dm"
	"NAMESPACE/global"
	"log"
	"os"
	"time"

	"github.com/cengsin/oracle"
	"go.uber.org/zap"
	"gorm.io/driver/mysql"
	"gorm.io/gorm"
	"gorm.io/gorm/logger"
	"gorm.io/gorm/schema"
)

var err error

func GormInitialize() {
	dbType := global.SERVER_CONFIG.SystemConfig.DbType
	switch dbType {
	case "mysql":
		GormMysql()
		break
	case "oracle":
		GormOracle()
		break
	case "dameng":
		GormDameng()
		break
	default:
		global.LOGGER.Error("数据库类型db-type配置不正确：" + dbType)
		//os.Exit(0)
		break
	}
}

func GormMysql() {
	m := global.SERVER_CONFIG.MySqlConfig
	dsn := m.Username + ":" + m.Password + "@tcp(" + m.Path + ")/" + m.Dbname + "?" + m.Config
	mysqlConfig := mysql.Config{
		DSN:                       dsn,   // DSN data source name
		DefaultStringSize:         191,   // string 类型字段的默认长度
		DisableDatetimePrecision:  true,  // 禁用 datetime 精度，MySQL 5.6 之前的数据库不支持
		DontSupportRenameIndex:    true,  // 重命名索引时采用删除并新建的方式，MySQL 5.7 之前的数据库和 MariaDB 不支持重命名索引
		DontSupportRenameColumn:   true,  // 用 `change` 重命名列，MySQL 8 之前的数据库和 MariaDB 不支持重命名列
		SkipInitializeWithVersion: false, // 根据版本自动配置
	}

	gormConfig := config(m.LogMode)
	global.LOGGER.Info("启动mysql...")
	if global.GORM_DB, err = gorm.Open(mysql.New(mysqlConfig), gormConfig); err != nil {
		global.LOGGER.Error("MySQL启动异常", zap.Any("err", err))
		//os.Exit(0)
	} else {
		GormDBTables(global.GORM_DB)
		sqlDB, _ := global.GORM_DB.DB()
		sqlDB.SetMaxIdleConns(m.MaxIdleConns)
		sqlDB.SetMaxOpenConns(m.MaxOpenConns)
	}
}

func GormDBTables(db *gorm.DB) {
	err := db.AutoMigrate(
	// to do ...
	)
	if err != nil {
		global.LOGGER.Error("注册数据表失败！", zap.Any("err", err))
		//os.Exit(0)
	}

	global.LOGGER.Info("注册数据表成功！")
}

func GormOracle() {
	m := global.SERVER_CONFIG.OracleConfig
	global.LOGGER.Info("连接oracle...")
	gormConfig := config(m.LogMode)
	//global.GORM_DB, err = gorm.Open(oracle.Open("ZTK/sirc1234@193.100.100.43:1521/ORCL"), &gorm.Config{
	global.GORM_DB, err = gorm.Open(oracle.Open(m.Username+"/"+m.Password+"@"+m.Path+"/"+m.Dbname), gormConfig)

	if err != nil {
		global.LOGGER.Error("连接失败", zap.Any("err", err))
		//os.Exit(0)
	}

	// 初始化各种结构
	//db = con
	if err = global.GORM_DB.AutoMigrate(
	//&model.UserModel{},

	); err != nil {
		global.LOGGER.Error("连接失败", zap.Any("err", err.Error()))
	}
}

func config(logMode bool) (c *gorm.Config) {
	if logMode {
		c = &gorm.Config{
			Logger: logger.New(log.New(os.Stdout, "\r\n", log.LstdFlags), logger.Config{
				SlowThreshold: 1 * time.Millisecond,
				LogLevel:      logger.Warn,
				Colorful:      true,
			}),
			DisableForeignKeyConstraintWhenMigrating: true,
			NamingStrategy: schema.NamingStrategy{
				TablePrefix:   "",
				SingularTable: true, //表名后面不加s
			},
		}
	} else {
		c = &gorm.Config{
			Logger:                                   logger.Default.LogMode(logger.Silent),
			DisableForeignKeyConstraintWhenMigrating: true,
			NamingStrategy: schema.NamingStrategy{
				TablePrefix:   "",
				SingularTable: true, //表名后面不加s

			},
			//Namer.ColumnName : func() {
			//
			//},
		}
	}
	return
}

//达梦数据库
func GormDameng() {
	m := global.SERVER_CONFIG.DamengConfig
	global.LOGGER.Info("连接达梦...")
	gormConfig := config(m.LogMode)
	//global.GORM_DB, err = gorm.Open(oracle.Open("ZTK/sirc1234@193.100.100.43:1521/ORCL"), &gorm.Config{
	global.GORM_DB, err = gorm.Open(dm.Open("dm://"+m.Username+":"+m.Password+"@"+m.Path+"?"+m.Config), gormConfig)
	if err != nil {
		global.LOGGER.Error("连接失败", zap.Any("err", err))
		//os.Exit(0)
	}

	// 初始化各种结构
	//db = con
	if err = global.GORM_DB.AutoMigrate(
	//&model.UserModel{},

	); err != nil {
		global.LOGGER.Error("连接失败", zap.Any("err", err.Error()))
	}
}
