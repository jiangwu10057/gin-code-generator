/**
* @Description 功能介绍
* @Author zhengjili
* @Date  2021/9/8  17:25
**/

package initialize

import (
	"NAMESPACE/global"
	"context"

	"github.com/minio/minio-go/v7"
	"github.com/minio/minio-go/v7/pkg/credentials"
	"go.uber.org/zap"
)

func OssInitialize() {
	OssCfg := global.SERVER_CONFIG.OssConfig
	ctx := context.Background()
	minioClient, err := minio.New(OssCfg.ImgPath, &minio.Options{
		Creds:  credentials.NewStaticV4(OssCfg.AccessKey, OssCfg.SecretKey, ""),
		Secure: false,
	})
	if err != nil {
		global.LOGGER.Error("oss connect ping failed, err:", zap.Any("err", err))
		return
	} else {
		err = minioClient.MakeBucket(ctx, OssCfg.Bucket, minio.MakeBucketOptions{Region: OssCfg.Zone})
		if err != nil {
			// 检查存储桶是否已经存在。
			exists, errBucketExists := minioClient.BucketExists(ctx, OssCfg.Bucket)
			if errBucketExists == nil && exists {
				global.Oss = minioClient
				global.LOGGER.Error("We already own %s\n", zap.Any("err", err))
			} else {
				global.LOGGER.Error("oss failed ", zap.Any("err", err))
			}
		} else {
			global.LOGGER.Info("Successfully created %s\n", zap.Any("bucket", OssCfg.Bucket))
			global.Oss = minioClient
		}
	}
}
