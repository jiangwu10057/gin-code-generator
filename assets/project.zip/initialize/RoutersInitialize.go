package initialize

import (
	_ "NAMESPACE/docs" //不加的话 swagger会报　swagger not yet registered swag错误
	"NAMESPACE/global"
	"NAMESPACE/middleware"
	"NAMESPACE/router"

	"github.com/gin-gonic/gin"
	"github.com/swaggo/gin-swagger"
	"github.com/swaggo/gin-swagger/swaggerFiles"
)

func RoutersInitialize() *gin.Engine {
	var Router = gin.Default()

	// 跨域
	Router.Use(middleware.CorsMiddleware())
	global.LOGGER.Info("use middleware cors")
	Router.Use(middleware.LoggerMiddleware())
	global.LOGGER.Info("use middleware logger")

	Router.GET("/swagger/*any", ginSwagger.WrapHandler(swaggerFiles.Handler))

	ApiGroup := Router.Group("api")
	router.InitBaseRouter(ApiGroup)
	global.LOGGER.Info("router register success")
	return Router
}
