package main

import (
	"NAMESPACE/core"
	"NAMESPACE/global"
	"NAMESPACE/initialize"
)

// @title 后台管理系统API
// @version 0.0.1
// @description <b>使用说明：</b>\n从统一认证平台获取token，用户登录令牌。<br/>
// @description <b>productId 对应说明：</b>
// @description da			：数据资产管理
// @description sm-vmc		：安全监控管理平台 - 可视化监控中心
// @description sm-ssas		：安全监控管理平台 - 安全监管审核系统
// @description sm-lcqs		：安全监控管理平台 - 日志归集查询系统
// @description dava		：数据资产价值评估系统
// @description dc			：开发者中心
// @description file		：文件平台
// @description beehub		：政务大数据蜂巢开发利用子平台
// @description beehub-ds	：数据实时查询系统
// @description dm			：可视化数据挖掘系统
// @description blockauth	：可信授权鉴证平台
// @description sm			：安全监控管理子平台
// @description bm			：后台管理系统<br/>
// @description <b>workbenchId 对应说明：</b>
// @description developer				：开发者
// @description social-data-provider	：社会数据提供方
// @description background-mgr			：运维管理-后台管理员（系统管理）
// @description product-opt				：运维管理-平台运维管理中心
// @description website-mgr				：运维管理-网站内容管理中心
// @description data-value-mgr			：运维管理-数据资产管理中心
// @description app-store-mgr			：运维管理-应用商店管理中心
// @description data-value-opt			：运维管理-数据资产运营中心
// @description self-service-mgr		：运维管理-自营服务管理中心
// @description self-data-product-mgr	：运维管理-自营数据产品管理中心
// @description company-account			：数据应用单位-单位管理账户
// @description member-account			：数据应用单位-成员账户
// @description province-data-office	：监管-省数办
// @description data-product-company	：监管-数据生产单位

// @securityDefinitions.apikey ApiKeyAuth
// @in header
// @name x-token
// @BasePath /
func main() {
	initialize.GormInitialize()

	db, _ := global.GORM_DB.DB()
	defer db.Close()

	core.RunWindowsServer()
}
