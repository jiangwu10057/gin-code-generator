/**
 * @Description 统一认证验证中间件
 * @Author q.wu
 * @Date 2020.11.30
 **/
package middleware

import (
	"NAMESPACE/global"
	"NAMESPACE/global/response"
	"NAMESPACE/global/sysproductconst"
	"NAMESPACE/model/request"
	"crypto/tls"
	"encoding/base64"
	"encoding/json"
	"fmt"
	"io/ioutil"
	"net/http"
	"net/url"
	"strconv"
	"strings"

	"github.com/gin-gonic/gin"
)

//permission 不需要登录，要登录，平台限制，只有后台能用。
func CentralizedAuthorizeMiddleware(permission int) gin.HandlerFunc {

	if permission == sysproductconst.PM_NO_NEED_LOGIN {

		return func(c *gin.Context) {
			token := c.Request.Header.Get("X-Token") // x-token 会被转为 X-Token
			if strings.Contains(token, ".") && len(token) > 0 {
				customClaimsModel, _ := getCustomClaimsModel(token)
				c.Set(global.MEMBER_BASIC_DATA_KEY, customClaimsModel)
			}

			c.Next()
		}
	}

	return func(c *gin.Context) {

		var authUrl = global.SERVER_CONFIG.CentralizedAuthorizeConfig.RemoteUrl + "/member/checkToken"

		token := c.Request.Header.Get("X-Token")                // x-token 会被转为 X-Token
		currentProductId := c.Request.Header.Get("X-ProductId") //当前登录的平台id
		routePath := c.Request.RequestURI                       //c.PostForm("routePath")

		http.DefaultTransport.(*http.Transport).TLSClientConfig = &tls.Config{InsecureSkipVerify: true} //忽略错误https证书

		global.LOGGER.Info(fmt.Sprintf("authUrl:>%s", authUrl))
		// global.LOGGER.Info(fmt.Sprintf("token:>%s", token))
		global.LOGGER.Info(fmt.Sprintf("routePath:>%s", routePath))
		global.LOGGER.Info(fmt.Sprintf("productId:>%s", currentProductId))

		//传键值对
		data := url.Values{}
		data.Set("routePath", routePath)

		req, err := http.NewRequest(http.MethodPost, authUrl, strings.NewReader(data.Encode()))

		//设置header
		req.Header.Set("x-token", token)
		req.Header.Set("x-productId", currentProductId)
		req.Header.Set("x-routePath", routePath)
		req.Header.Add("Content-Type", "application/x-www-form-urlencoded")
		req.Header.Add("Content-Length", strconv.Itoa(len(data.Encode())))

		client := &http.Client{}
		resp, err := client.Do(req)
		if err != nil {
			errMsg := fmt.Sprintf("统一认证返回出错：%v", err)
			response.InternalServerError(errMsg, c)
			c.Abort()
			return
		}
		defer resp.Body.Close()

		//fmt.Println("response Status:", resp.Status)
		//fmt.Println("response Headers:", resp.Header)
		var m response.Response
		//var m  response.Response
		m.Code = "-2"

		body, _ := ioutil.ReadAll(resp.Body)
		fmt.Println("response Body:", string(body))
		err = json.Unmarshal(body, &m)
		if err != nil {
			errMsg := fmt.Sprintf("统一认证返回出错：%v", err)
			response.InternalServerError(errMsg, c)
			c.Abort()
			return
		}

		if m.Code != "0" {
			response.FailWithCustomCode(m.Code, m.Message, c)
			c.Abort()
			return
		}

		//保存用户信息
		customClaimsModel, _ := getCustomClaimsModel(token)

		var havePermission = false
		switch permission {

		case sysproductconst.PM_ONLY_NEED_LOGIN:
			havePermission = true
			break

		case sysproductconst.PM_PRODUCT_LIMIT, sysproductconst.PM_ONLY_BACKGROUND:
			productArr := strings.Split(customClaimsModel.ProductIds, ",")

			for _, v := range productArr {
				if permission == sysproductconst.PM_ONLY_BACKGROUND {
					if v == sysproductconst.BACKGROUND_MANAGEMENT { //大后台
						havePermission = true
						break
					}
				} else if v == sysproductconst.BACKGROUND_MANAGEMENT || v == sysproductconst.BEE_HUB || v == sysproductconst.BEE_HUB_DS || v == sysproductconst.OPERATION_MAINTENANCE || v == sysproductconst.SECURITY_MONITOR || v == sysproductconst.DATA_VALUE_OPERATION || v == sysproductconst.DATA_SET { //大后台和蜂巢都能访问
					havePermission = true
					break
				}
			}
			break

		default:
			break
		}

		if !havePermission {
			response.FailWithMessage("您没有访问当前平台的权限！", c)
			c.Abort()
			return
		}

		if strings.TrimSpace(currentProductId) == "" {
			fmt.Println("x-productId不存在")
		} else {
			customClaimsModel.CurrentProductId = currentProductId
		}
		c.Set(global.MEMBER_BASIC_DATA_KEY, customClaimsModel)
		c.Next()
	}
}

// 解析token
func getCustomClaimsModel(tokenString string) (*request.CustomClaimsModel, error) {
	var m2 request.CustomClaimsModel
	//tokenString = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJVVUlEIjoiZDAxY2Y5MmEtY2MwNS00YTQwLWFiZTgtZWI2NzU5YjdmZDZiIiwiSUQiOiIzRjBBMUZGMkQ4MTc0RDhGQkYxNTgyQTM3N0I0MDVFNSIsIlVzZXJOYW1lIjoi5YWs5a6J5Y6F55So5oi3MSIsIk5pY2tOYW1lIjoiIiwiQXV0aG9yaXR5SWQiOiIiLCJCdWZmZXJUaW1lIjowLCJleHAiOjE2MDcxMzUxMzYsImlzcyI6IkNlbnRyYWxpemVkQXV0aG9yaXplIiwibmJmIjoxNjA3MDQ3NzM2fQ.e3d1_7HxRJ700xDcPmK9SewGpLd4PqAE5BPFnehXFXU"
	payload := strings.Split(tokenString, ".")[1]
	jsonStr, err := base64.RawURLEncoding.DecodeString(payload)
	if err != nil {
		global.LOGGER.Error(fmt.Sprintf("解析JWT错误:%v", err))
		return nil, err
	}
	err = json.Unmarshal(jsonStr, &m2)
	if err != nil {
		global.LOGGER.Error(fmt.Sprintf("Unmarshal JWT错误:%v", err))
		return nil, err
	}

	return &m2, nil
}
