package model

type CommonMap map[string]interface{}

type PageInfoModel struct {
	Page     int `json:"page" form:"page" gorm:"-"`
	PageSize int `json:"pageSize" form:"pageSize" gorm:"-" `
}

const DefaultTimeFormat = "2006-01-02 15:04:05"
const (
	Page        = 1    // 当前页数
	PageSize    = 20   // 每页多少条数据
	MaxPageSize = 1000 // 每次最多取多少条
)

func (model *PageInfoModel) parsePageAndPageSize(params CommonMap) {
	page, ok := params["Page"]
	if ok {
		model.Page = page.(int)
	}
	pageSize, ok := params["PageSize"]
	if ok {
		model.PageSize = pageSize.(int)
	}
	if model.Page <= 0 {
		model.Page = Page
	}
	if model.PageSize <= 0 {
		model.PageSize = MaxPageSize
	}
}

func (model *PageInfoModel) pageLimitOffset() int {
	return (model.Page - 1) * model.PageSize
}
