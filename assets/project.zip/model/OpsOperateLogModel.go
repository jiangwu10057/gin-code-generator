/**
* @Description 登录日志模型
* @Author zhengjili
* @Date  2021/5/10  16:05
**/

package model

type OpsOperateLogModel struct {
	LogId         string `json:"logId" gorm:"column:LOG_ID;comment:日志ID;primary_key"`                             //日志ID
	ProductId     string `json:"productId" gorm:"column:PRODUCT_ID"`                                              //所属工作台
	ProductName   string `json:"productName" gorm:"column:PRODUCT_NAME "`                                         //工作台名称
	ClientIp      string `json:"clientId" gorm:"column:CLIENT_IP"`                                                //客户端IP
	UserId        string `json:"userId" gorm:"column:USER_ID"`                                                    //操作者Id
	UserName      string `json:"userName"  gorm:"column:USER_NAME"`                                               //操作者
	WarnInfo      string `json:"warnInfo" gorm:"column:WARN_INFO"`                                                //告警信息
	CreatTime     MyTime `json:"creatTime" gorm:"column:CREATE_TIME;comment:创建时间" swaggerignore:"true"`           //创建时间
	IsDelete      int    `json:"isDelete" gorm:"column:IS_DELETE;comment:是否删除（1-已删除 2-未删除）" swaggerignore:"true"` //是否删除（1-已删除 2-未删除）
	OperateType   int    `json:"operateType" gorm:"column:OPERATE_TYPE"`                                          //1登录；2退出；3添加；4修改；5删除操作
	ModuleType    int    `json:"moduleType"  gorm:"column:MODULE_TYPE"`                                           //模块类型：1:登录日志审核；2:操作监控
	OperateDetail string `json:"operateDetail" gorm:"column:OPERATE_DETAIL"`                                      //操作详情
	SolveStatus   int    `json:"solveStatus" gorm:"column:SOLVE_STATUS"`                                          //解决状态1:已忽略；2已解决
	ModifyTime    MyTime `json:"modifyTime" gorm:"column:MODIFY_TIME;comment:修改时间" `
}

func (OpsOperateLogModel) TableName() string {
	return "OPS_OPERATE_LOG"
}
