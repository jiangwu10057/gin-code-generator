/**
* @Description 登录日志模型
* @Author zhengjili
* @Date  2021/5/10  16:05
**/

package model

type OpsOperateLogModel struct {
	LogId         string `json:"logId" gorm:"column:LOG_ID;comment:日志ID;primary_key"`                             //日志ID
	ProductId     string `json:"productId" gorm:"column:PRODUCT_ID"`                                              //所属工作台
	ProductName   string `json:"productName" gorm:"column:PRODUCT_NAME "`                                         //工作台名称
	ClientIp      string `json:"clientIp" gorm:"column:CLIENT_IP"`                                                //客户端IP
	UserId        string `json:"userId" gorm:"column:USER_ID"`                                                    //操作者Id
	UserName      string `json:"userName"  gorm:"column:USER_NAME"`                                               //操作者
	OperateDetail string `json:"operateDetail" gorm:"column:OPERATE_DETAIL"`                                      //操作详情
	WarnInfo      string `json:"warnInfo" gorm:"column:WARN_INFO"`                                                //告警信息
	CreatTime     MyTime `json:"creatTime" gorm:"column:CREATE_TIME;comment:创建时间" swaggerignore:"true"`           //创建时间
	IsDelete      int    `json:"isDelete" gorm:"column:IS_DELETE;comment:是否删除（1-已删除 2-未删除）" swaggerignore:"true"` //是否删除（1-已删除 2-未删除）
	SolveStatus   int    `json:"solveStatus" gorm:"column:SOLVE_STATUS"`                                          //解决状态1:已忽略；2已解决
	ModifyTime    MyTime `json:"modifyTime" gorm:"column:MODIFY_TIME;comment:修改时间" `                              //修改时间
	LogType       int    `json:"logType"  gorm:"column:LOG_TYPE"`                                                 //日志类型：1:登录日志审核；2:操作监控
	Remark        string `json:"remark" gorm:"column:REMARK"`                                                     //备注
	UserAccount   string `json:"userAccount" gorm:"column:USER_ACCOUNT"`                                          //操作者账号
	WorkbenchId   string `json:"workbenchId" gorm:"column:WORKBENCH_ID"`                                          //工作台ID
	ModuleName    string `json:"moduleName"  gorm:"column:MODULE_NAME"`                                           //所属模块
	OperateObject string `json:"operateObject" gorm:"column:OPERATE_OBJECT"`                                      //操作对象
	OperateType   string `json:"operateType" gorm:"column:OPERATE_TYPE"`                                          //操作类型：登录；退出；编辑资料；创建账号；审批场景……
	OperateDevice string `json:"operateDevice" gorm:"column:OPERATE_DEVICE"`                                      //操作设备
	MemberId      string `json:"memberId" gorm:"column:MEMBER_ID"`                                                //单位ID
	ClientAddress string `json:"clientAddress" gorm:"column:CLIENT_ADDRESS"`                                      //操作地点

}

func (OpsOperateLogModel) TableName() string {
	return "OPS_OPERATE_LOG"
}

type BlockChainModel struct {
	AppKey string                 `json:"appKey"`
	Params map[string]interface{} `json:"params"`
}
