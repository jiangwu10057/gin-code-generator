package request

//分页请求结构体
type PageInfoModel struct {
	Page     int `json:"page" form:"page" comment:"页码，从1开始"`       //页码，从1开始
	PageSize int `json:"pageSize" form:"pageSize" comment:"每页记录数"` //每页记录数
}

// Find by id structure
type IdModel struct {
	Id string `json:"id" form:"id" binding:"required"`
}

// Find by name structure
type NameModel struct {
	Name string `json:"name" form:"name"`
}

// Find by ids structure
type IdsModel struct {
	Ids []string `json:"ids" form:"ids"`
}

//短信结构体
type Sms struct {
	SendType             string `json:"sendType" form:"sendType"` //发送类型 默认手机号
	MobilePhoneOrAccount string `json:"mobilePhoneOrAccount"`     //手机号/账号
	CaptchaId            string `json:"captchaId"`                //验证码id
	CaptchaCode          string `json:"captchaCode"`              //验证码
}
