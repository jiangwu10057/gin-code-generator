package request

import (
	"NAMESPACE/model"

	"github.com/dgrijalva/jwt-go"
)

// Custom claims structure
type CustomClaimsModel struct {
	UUID             string           `json:"uuid" comment:"令牌ID"`
	MemberId         string           `json:"memberId" comment:"机构ID"`
	UserId           string           `json:"userId" comment:"用户ID"`
	UserName         string           `json:"userName" comment:"用户名"`
	NickName         string           `json:"nickName" comment:"昵称"`
	Avatar           model.ClobString `json:"avatar" comment:"头像"`
	ProductIds       string           `json:"productIds" comment:"产品ID"` //多个时逗号","隔开
	UserType         int              `json:"userType" comment:"1-机构普通用户 2-机构管理用户 3-平台管理用户"`
	WorkbenchIds     string           `json:"workbenchIds" comment:"工作台ID"`                        //多个时逗号","隔开
	CnName           string           `json:"cnName" comment:"工作单位"`                               //多个时逗号","隔开
	IsForceUpdatePwd int              `gorm:"column:IS_FORCE_UPDATE_PWD;comment:是否强制重置密码（1-是2-否）"` //是否强制重置密码（1-是2-否）
	//AuthorityId string
	//BufferTime  int64
	jwt.StandardClaims
}
