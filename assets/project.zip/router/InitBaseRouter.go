/**
 * @Description $
 * @Author $
 * @Date $ $
 **/
package router

import (
	v1 "NAMESPACE/api/v1"

	"github.com/gin-gonic/gin"
)

func InitBaseRouter(r *gin.RouterGroup) (R gin.IRoutes) {
	BaseRouter := r.Group("v1/base")
	{
		//BaseRouter.POST("login", v1.Login)
		BaseRouter.GET("captcha", v1.Captcha)
	}
	return BaseRouter
}
