/**
* @Description:
* @Author: q.wu
* @Date: 2021/9/3 15:59
 */
package service

import (
	"NAMESPACE/global"
	"NAMESPACE/utils/encrypt"
)

var dbPrefix = global.DB_PREFIX

//工具
var bcryptUtils encrypt.BcryptUtils

var memberAccountTable = ""
