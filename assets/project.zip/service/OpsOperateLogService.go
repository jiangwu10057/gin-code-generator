/**
* @Description 登录日志模块
* @Author zhengjili
* @Date  2021/5/10  16:29
**/

package service

import (
	"NAMESPACE/global"
	"NAMESPACE/model"
	"NAMESPACE/utils"
	"encoding/json"
	"errors"
	"net/http"
	"strconv"
	"time"
)

type OpsLoginLogService struct {
}

//操作监控
func (*OpsLoginLogService) OperateLog(m model.OpsOperateLogModel) (err error) {
	err = global.GORM_DB.Raw("SELECT PRODUCT_NAME FROM "+dbPrefix+"SYS_PRODUCT WHERE PRODUCT_ID=?", m.ProductId).Scan(&m.ProductName).Error
	if err != nil {
		return err
	}
	err = global.GORM_DB.Raw("SELECT USER_ACCOUNT FROM "+memberAccountTable+" WHERE USER_ID=? AND STATUS=1 AND IS_DELETE=2", m.UserId).Scan(&m.UserAccount).Error
	if err != nil {
		return err
	}
	err = global.GORM_DB.Exec("INSERT INTO  "+dbPrefix+"OPS_OPERATE_LOG("+
		"PRODUCT_ID,PRODUCT_NAME,CLIENT_IP,USER_ID,USER_NAME,OPERATE_DETAIL,WARN_INFO,LOG_TYPE,REMARK,USER_ACCOUNT,WORKBENCH_ID,MODULE_NAME,OPERATE_OBJECT,OPERATE_DEVICE,MEMBER_ID,CLIENT_ADDRESS,OPERATE_TYPE) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?) ",
		m.ProductId, m.ProductName, m.ClientIp, m.UserId, m.UserName, m.OperateDetail, m.WarnInfo, m.LogType, m.Remark, m.UserAccount, m.WorkbenchId, m.ModuleName, m.OperateObject, m.OperateDevice, m.MemberId, m.ClientAddress, m.OperateType).Error

	return err
}

//操作日志发送到区块链
func (ops *OpsLoginLogService) SendOperateLog(m model.OpsOperateLogModel) error {
	err := global.GORM_DB.Raw("SELECT PRODUCT_NAME FROM "+dbPrefix+"SYS_PRODUCT WHERE PRODUCT_ID=?", m.ProductId).Scan(&m.ProductName).Error
	if err != nil {
		return err
	}
	err = global.GORM_DB.Raw("SELECT USER_ACCOUNT FROM "+memberAccountTable+" WHERE USER_ID=? AND STATUS=1 AND IS_DELETE=2", m.UserId).Scan(&m.UserAccount).Error
	if err != nil {
		return err
	}

	var now = time.Now().Format("2006-01-02 15:04:05")

	params := make(map[string]interface{})
	params["productId"] = m.ProductId
	params["productName"] = m.ProductName
	params["clientIp"] = m.ClientIp
	params["userId"] = m.UserId
	params["userName"] = m.UserName
	params["operateDetail"] = m.OperateDetail
	params["warnInfo"] = ""
	params["createTime"] = now
	params["solveStatusText"] = ""
	params["modifyTime"] = now
	params["logTypeText"] = "操作监控"
	params["remark"] = ""
	params["userAccount"] = m.UserAccount
	params["workbenchId"] = m.WorkbenchId
	params["moduleName"] = m.ModuleName
	params["operateObject"] = m.OperateObject
	params["operateType"] = m.OperateType
	params["operateDevice"] = m.OperateDevice
	params["memberId"] = m.MemberId
	params["clientAddress"] = m.ClientAddress

	data := model.BlockChainModel{
		AppKey: global.SERVER_CONFIG.BlackChainConfig.AppKey,
		Params: params,
	}
	json, err := json.Marshal(data)
	if err != nil {
		return err
	}
	global.LOGGER.Info("上报区块链操作日志," + string(json))
	res := utils.PostJson(global.SERVER_CONFIG.BlackChainConfig.Url, string(json), 10)
	global.LOGGER.Info("上报区块链操作日志结果：" + res.Body + ",状态码:" + strconv.Itoa(res.StatusCode))
	if res.StatusCode != http.StatusOK {
		return errors.New("发送日志失败")
	}
	return nil
}
