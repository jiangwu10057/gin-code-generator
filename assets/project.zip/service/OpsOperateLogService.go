/**
* @Description 登录日志模块
* @Author zhengjili
* @Date  2021/5/10  16:29
**/

package service

import (
	"NAMESPACE/global"
	"NAMESPACE/model"
	"strings"
)

type OpsOperateLogService struct {
}

//操作监控
func (*OpsOperateLogService) OperateLog(m model.OpsOperateLogModel) (err error) {
	err = global.GORM_DB.Raw("SELECT PRODUCT_NAME FROM "+dbPrefix+"SYS_PRODUCT WHERE PRODUCT_ID=?", strings.Split(m.ProductId, ",")[0]).Scan(&m.ProductName).Error
	if err != nil {
		return err
	}
	err = global.GORM_DB.Exec("INSERT INTO  "+dbPrefix+"OPS_OPERATE_LOG(LOG_ID,PRODUCT_ID,PRODUCT_NAME,CLIENT_IP,USER_ID,USER_NAME,OPERATE_DETAIL,OPERATE_TYPE,WARN_INFO,MODULE_TYPE) VALUES(?,?,?,?,?,?,?,?,?,?) ", m.LogId, m.ProductId, m.ProductName, m.ClientIp, m.UserId, m.UserName, m.OperateDetail, m.OperateType, m.WarnInfo, m.ModuleType).Error

	return err
}
