package service

import (
	"NAMESPACE/global"
)

var dbPrefix = global.DB_PREFIX
