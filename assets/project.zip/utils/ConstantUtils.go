package utils

const (
	ConfigEnv  = "CUSTOM_CONFIG"
	ConfigFile = "config.yaml"
)
