package utils

import (
	"NAMESPACE/global"
	"errors"
	"mime/multipart"
	"net/http"
	"os"
	"strings"
)

type FileUtils struct {
}

//func GetFileContentType(out *os.File) (string, error) {
func (_ *FileUtils) GetFileContentType(out *os.File) (string, error) {

	// Only the first 512 bytes are used to sniff the content type.
	buffer := make([]byte, 512)

	_, err := out.Read(buffer)
	if err != nil {
		return "", err
	}

	// Use the net/http package's handy DectectContentType function. Always returns a valid
	// content-type by returning "application/octet-stream" if no others seemed to match.
	contentType := http.DetectContentType(buffer)

	return contentType, nil
}

func (_ *FileUtils) GetFileContentTypeByFileHeader(fileHeader *multipart.FileHeader) (string, error) {
	f, err := fileHeader.Open()
	defer f.Close()
	if err != nil {
		return "", err
	}
	buffer := make([]byte, 512)
	f.Read(buffer)
	contentType := http.DetectContentType(buffer)
	return contentType, nil
}

func (_ *FileUtils) VerifyFileExt(contentType string) error {
	extArr := strings.Split(global.SERVER_CONFIG.LocalConfig.AllowFileExt, ",")
	for _, val := range extArr {
		if contentType == strings.Trim(val, "") {
			return nil
		}
	}
	return errors.New("文件格式不正确！")
}
