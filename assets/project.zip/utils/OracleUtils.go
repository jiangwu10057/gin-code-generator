/**
* @Description ORACLE 的增改操作的封装
* @Author zhengjili
* @Date  2020/11/25  11:26
**/

package utils

import (
	"NAMESPACE/global"
	"NAMESPACE/model"
	"fmt"
	"reflect"
	"strings"
	"time"

	"gorm.io/gorm"
)

//插入
func Insert(db *gorm.DB, table string, v interface{}) error {
	sql, args := GetInsertSql(v, table)

	DB := db.Exec(sql, args...)
	if DB.Error != nil {
		return DB.Error
	}
	DB.Rollback()
	return nil
}

//修改操作
func Update(db *gorm.DB, v interface{}) error {
	sql, args := getUpdateSql(v)
	DB := db.Exec(sql, args...)
	if DB.Error != nil {
		return DB.Error
	}
	//fmt.Println(sql)
	//fmt.Println(args)
	return nil
}

// 获取插入的更新语句及需要插入的数据
func GetInsertSql(v interface{}, table string) (string, []interface{}) {
	elem := reflect.ValueOf(v)
	if elem.Kind() == reflect.Ptr {
		elem = elem.Elem()
	}
	elemType := elem.Type()
	tableName := global.DB_PREFIX + table
	numFields := elem.NumField()
	insertFields := make([]string, 0, numFields)
	insertValues := make([]interface{}, 0, numFields)
	for i := 0; i < numFields; i++ {
		curField := elem.Field(i)
		curStruct := elemType.Field(i)
		field := normalize(curStruct.Tag.Get("gorm"))
		fieldName := strings.Split(strings.Split(field, ":")[1], ";")[0]
		var fieldValue interface{}
		switch curField.Kind() {
		case reflect.Bool:
			if curField.Bool() {
				fieldValue = "1"
			} else {
				fieldValue = "0"
			}
		case reflect.Int, reflect.Int8, reflect.Int16, reflect.Int32, reflect.Int64:
			if curField.Int() == 0 {
				continue
			}
			fieldValue = curField.Int()
		case reflect.Uint, reflect.Uint8, reflect.Uint16, reflect.Uint32, reflect.Uint64:
			if curField.Uint() == 0 {
				continue
			}
			fieldValue = curField.Uint()
		case reflect.Float32, reflect.Float64:
			if curField.Float() == 0 {
				continue
			}
			fieldValue = curField.Float()
		case reflect.String:
			if len(curField.String()) == 0 {
				continue
			}
			field := normalize(curStruct.Tag.Get("type"))
			if field == "time" {
				t, err := time.Parse("2006-01-02 15:04:05", curField.String())
				if err != nil {
					fieldValue = ""

				} else {
					fieldValue = t
				}
			} else {
				fieldValue = curField.String()
			}

		case reflect.Struct:
			if curField.IsZero() {
				continue
			}
			fieldValue = curField.Interface()
		}
		insertFields = append(insertFields, fieldName)
		insertValues = append(insertValues, fieldValue)
	}
	quotes := strings.Repeat("?,", len(insertFields))
	quotes = quotes[0 : len(quotes)-1]
	ret := fmt.Sprintf("insert into %s(%s) values(%s)", tableName, strings.Join(insertFields, ","), quotes)
	//elem := reflect.ValueOf(v)
	//if elem.Kind() == reflect.Ptr {
	//	elem = elem.Elem()
	//}
	//elemType := elem.Type()
	//tableName := dbPrefix + table
	//numFields := elem.NumField()
	//insertFields := make([]string, 0, numFields)
	//insertValues := make([]interface{}, 0, numFields)
	//for i := 0; i < numFields; i++ {
	//	curField := elem.Field(i)
	//	curStruct := elemType.Field(i)
	//	field, val, _ := parseField(curField, curStruct)
	//	insertFields = append(insertFields, field)
	//	insertValues = append(insertValues, val)
	//}
	//quotes := strings.Repeat("?,", len(insertFields))
	//quotes = quotes[0 : len(quotes)-1]
	//ret := fmt.Sprintf("insert into %s(%s) values(%s)", tableName, strings.Join(insertFields, ","), quotes)
	return ret, insertValues
}

//获取更新时的sql语句及需要更新的数据
func getUpdateSql(v interface{}) (string, []interface{}) {
	elem := reflect.ValueOf(v)
	if elem.Kind() == reflect.Ptr {
		elem = elem.Elem()
	}
	var pk string
	var pkValue interface{}
	elemType := elem.Type()
	tableName := global.DB_PREFIX + elem.Method(0).Call(nil)[0].String()
	numFields := elem.NumField()
	updateFields := make([]string, 0, numFields)
	updateValues := make([]interface{}, 0, numFields)
	for i := 0; i < numFields; i++ {
		curField := elem.Field(i)
		curStruct := elemType.Field(i)

		var isPk bool
		field := normalize(curStruct.Tag.Get("gorm"))
		fieldName := strings.Split(strings.Split(field, ":")[1], ";")[0]
		if len(strings.Split(field, ";")) > 1 && strings.Split(field, ";")[1] == "primary_key" {
			isPk = true
		}
		var fieldValue interface{}

		switch curField.Kind() {
		case reflect.Bool:
			if curField.Bool() {
				fieldValue = "1"
			} else {
				fieldValue = "0"
			}
		case reflect.Int, reflect.Int8, reflect.Int16, reflect.Int32, reflect.Int64:
			if curField.Int() == 0 {
				continue
			}
			fieldValue = curField.Int()
		case reflect.Uint, reflect.Uint8, reflect.Uint16, reflect.Uint32, reflect.Uint64:
			if curField.Uint() == 0 {
				continue
			}
			fieldValue = curField.Uint()
		case reflect.Float32, reflect.Float64:
			if curField.Float() == 0.0 {
				continue
			}
			fieldValue = curField.Float()
		case reflect.String:
			if len(curField.String()) == 0 {
				if fieldName == "modify_time" {
					fieldValue = time.Now()
				} else {
					continue
				}
			} else {
				field := normalize(curStruct.Tag.Get("type"))
				if field == "time" {
					t, err := time.Parse("2006-01-02 15:04:05", curField.String())
					if err != nil {
						fieldValue = ""

					} else {
						fieldValue = t
					}
				} else {
					fieldValue = curField.String()
				}
			}

		case reflect.Struct:
			if t, ok := curField.Interface().(time.Time); ok {
				if t.IsZero() {
					continue
				}
			}
			if t, ok := curField.Interface().(model.MyTime); ok {
				if t.IsZero() {
					continue
				}
			}
			fieldValue = curField.Interface()
		}

		//field, val, isPk := parseField(curField, curStruct)
		if !isPk {
			updateFields = append(updateFields, fieldName)
			updateValues = append(updateValues, fieldValue)
		} else {
			pk = fieldName
			pkValue = fieldValue

		}

	}
	if pk != "" {
		updateValues = append(updateValues, pkValue)
	}
	updateFields = append(updateFields, "")
	str := strings.Join(updateFields, "=?,")
	str = strings.TrimRight(str, ",")
	quotes := strings.Repeat("?,", 1)
	quotes = quotes[0 : len(quotes)-1]
	ret := fmt.Sprintf("update %s set %s where %s=?", tableName, str, pk)
	return ret, updateValues
}

func parseField(v reflect.Value, s reflect.StructField) (string, interface{}, bool) {
	var isPk bool
	isPk = false
	field := s.Tag.Get("gorm")
	fieldName := strings.Split(strings.Split(field, ":")[1], ";")[0]
	if len(strings.Split(field, ";")) > 1 && strings.Split(field, ";")[1] == "primary_key" {
		isPk = true
	}
	var fieldValue interface{}
	switch v.Kind() {
	case reflect.Bool:
		if v.Bool() {
			fieldValue = "1"
		} else {
			fieldValue = "0"
		}
	case reflect.Int, reflect.Int8, reflect.Int16, reflect.Int32, reflect.Int64:
		fieldValue = v.Int()
	case reflect.Uint, reflect.Uint8, reflect.Uint16, reflect.Uint32, reflect.Uint64:
		fieldValue = v.Uint()
	case reflect.Float32, reflect.Float64:
		fieldValue = v.Float()
	case reflect.String:
		field := normalize(s.Tag.Get("type"))
		if field == "time" {
			t, err := time.Parse("2006-01-02 15:04:05", v.String())
			if err != nil {
				fieldValue = ""

			} else {
				fieldValue = t
			}
		} else {
			fieldValue = v.String()
		}
	case reflect.Struct:
		fieldValue = v.Interface()
	}
	return fieldName, fieldValue, isPk
}

func normalize(str string) string {
	return strings.ToLower(str)
}
