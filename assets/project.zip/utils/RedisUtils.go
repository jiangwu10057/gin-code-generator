/**
* @Description: redis辅助工具
* @Author: q.wu
* @Date: 2022/6/7 10:17
 */
package utils

import (
	"encoding/json"
	"github.com/go-redis/redis"
	"time"
)

type RedisUtils struct {
}

//存储结构体
func (RedisUtils) SetStruct(c *redis.Client, key string, value interface{}, expiration time.Duration) error {
	if value == nil {
		return nil
	}
	
	p, err := json.Marshal(value)
	if err != nil {
		return err
	}

	err = c.Set(key, p, expiration).Err()
	if err == redis.Nil{
		return nil
	}
	return err
}

//获取结构体
func (RedisUtils) GetStruct(c *redis.Client, key string, dest interface{}) error {
	p, err := c.Get(key).Result()

	if err == redis.Nil{
		return nil
	}

	if err != nil {
		return err
	}
	return json.Unmarshal([]byte(p), dest)
}

//根据规则删除缓存
func (RedisUtils) RemoveCacheByPattern(c *redis.Client, cacheKey string) (int, error) {
	var cnt = 0
	iter := c.Scan(0, cacheKey, 0).Iterator()
	for iter.Next() {
		c.Del(iter.Val())
		cnt++
	}

	return cnt, iter.Err()
}
