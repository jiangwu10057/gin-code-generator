package utils

import (
	"NAMESPACE/global"
	"NAMESPACE/utils/encrypt"
	"context"
	"fmt"
	"io"
	"mime/multipart"
	"os"
	"path"
	"strings"
	"time"

	"github.com/minio/minio-go/v7"
	"go.uber.org/zap"
)

type UploadFileUtils struct {
}

var fileUtils FileUtils

func (_ *UploadFileUtils) UploadFileLocal(fileHeader *multipart.FileHeader, file io.Reader) (err error, localPath string, key string) {
	contentType, _ := fileUtils.GetFileContentTypeByFileHeader(fileHeader)
	fmt.Println(contentType)
	if err = fileUtils.VerifyFileExt(contentType); err != nil {
		return err, "", ""
	}

	// 读取文件后缀
	ext := path.Ext(fileHeader.Filename)
	// 读取文件名并加密
	fileName := strings.TrimSuffix(fileHeader.Filename, ext)
	fileName = encrypt.MD5V([]byte(fileName))
	// 拼接新文件名
	lastName := fileName + "_" + time.Now().Format("20060102150405") + ext
	// 读取全局变量的定义路径
	savePath := global.SERVER_CONFIG.LocalConfig.UploadPath
	// 尝试创建此路径
	err = os.MkdirAll(savePath, os.ModePerm)
	if err != nil {
		global.LOGGER.Error("upload local fileHeader fail:", zap.Any("err", err))
		return err, "", ""
	}
	// 拼接路径和文件名
	dst := savePath + "/" + lastName
	// 下面为上传逻辑
	// 打开文件 defer 关闭
	src, err := fileHeader.Open()
	if err != nil {
		global.LOGGER.Error("upload local fileHeader fail:", zap.Any("err", err))
		return err, "", ""
	}
	defer src.Close()
	// 创建文件 defer 关闭
	out, err := os.Create(dst)
	if err != nil {
		global.LOGGER.Error("upload local fileHeader fail:", zap.Any("err", err))
		return err, "", ""
	}
	defer out.Close()
	// 传输（拷贝）文件
	_, err = io.Copy(out, src)
	if err != nil {
		global.LOGGER.Error("upload local fileHeader fail:", zap.Any("err", err))
		return err, "", ""
	}
	return nil, dst, lastName
}

func (_ *UploadFileUtils) UploadFileToMinio(fileHeader *multipart.FileHeader, file io.Reader) (err error, localPath string, key string) {
	ctx := context.Background()
	contentType, _ := fileUtils.GetFileContentTypeByFileHeader(fileHeader)
	//if err := fileUtils.VerifyFileExt(contentType); err != nil {
	//	return err, "", ""
	//}

	// 读取文件后缀
	ext := path.Ext(fileHeader.Filename)
	// 读取文件名并加密
	fileName := strings.TrimSuffix(fileHeader.Filename, ext)
	fileName = encrypt.MD5V([]byte(fileName))
	// 拼接新文件名
	lastName := fileName + "_" + time.Now().Format("20060102150405") + ext
	src, err := fileHeader.Open()
	if err != nil {
		return err, "", ""
	}
	n, err := global.Oss.PutObject(ctx, global.SERVER_CONFIG.OssConfig.Bucket, lastName, src, -1, minio.PutObjectOptions{ContentType: contentType})
	if err != nil {
		return err, "", ""
	}
	return nil, n.Location, fileHeader.Filename
}
