/**
* @Description 生成唯一标识符UUID
* @Author zhengjili
* @Date  2020/12/1  10:30
**/

package utils

import (
	"strings"

	uuid "github.com/satori/go.uuid"
)

func GetUUID() string {
	u2 := uuid.NewV4()

	str := strings.ReplaceAll(u2.String(), "-", "")
	str = strings.ToUpper(str)
	return str
}
