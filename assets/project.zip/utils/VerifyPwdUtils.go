/**
* @Description 功能介绍
* @Author zhengjili
* @Date  2020/12/15  8:54
**/

package utils

import (
	"fmt"
	"unicode"
)

func VerifyPassword(s string) error {
	if len(s) < 6 || len(s) > 32 {
		return fmt.Errorf("密码长度必须是 6 到 32 个字符之间")
	}
	var hasNumber, hasUpperCase, hasLowercase bool
	for _, c := range s {
		switch {
		case unicode.IsNumber(c):
			hasNumber = true
		case unicode.IsUpper(c):
			hasUpperCase = true
		case unicode.IsLower(c):
			hasLowercase = true
		case c == '@' || c == '_' || c == '-' || c == '?' || c == '!' || c == '#':
			continue
		case unicode.IsPunct(c) || unicode.IsSymbol(c):
			return fmt.Errorf("密码只能包含数字、大小写英文字母及常用符号")
		}
	}
	if !(hasNumber && (hasUpperCase || hasLowercase)) {
		return fmt.Errorf("密码过于简单，密码必须包含数字、字母")
	}
	return nil
}
func VerifyAccount(s string) error {
	if len(s) < 1 || len(s) > 64 {
		return fmt.Errorf(`长度1-64位的字母、数字或"_"`)
	}
	var hasAnother bool
	for _, c := range s {
		switch {
		case unicode.IsNumber(c):
			hasAnother = true
		case unicode.IsUpper(c):
			hasAnother = true
		case unicode.IsLower(c):
			hasAnother = true
		case c == '_':
			hasAnother = true
		default:
			hasAnother = false
			return fmt.Errorf(`长度1-64位的字母、数字或"_"`)
		}
	}
	if !hasAnother {
		return fmt.Errorf(`长度1-64位的字母、数字或"_"`)
	}
	return nil
}
func CheckPWDStrong(s string) int {
	var score, level int
	if len(s) > 8 && len(s) < 10 {
		score += 10
	} else if len(s) >= 10 {
		score += 25
	}
	var hasNumber, hasUpperCase, hasLowercase int
	for _, c := range s {
		switch {
		case unicode.IsNumber(c):
			hasNumber++
		case unicode.IsUpper(c):
			hasUpperCase++
		case unicode.IsLower(c):
			hasLowercase++
		}
	}
	if hasUpperCase > 0 && hasLowercase > 0 {
		score += 20
	}
	if hasNumber >= 1 && hasNumber < 3 {
		score += 10
	} else if hasNumber >= 3 {
		score += 20
	}
	score += 2
	if score > 60 && score < 80 {
		level = 1
	} else if score >= 80 {
		level = 2
	}
	return level

}
